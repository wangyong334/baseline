"""模块三：目标级航迹头（model/track_head.py）的训练与评估入口（Stream-SNN-Innovations.md 13.60～13.61）。

骨干（E3a 等已训练的流式网络）冻结、只读；只训练航迹头。每条录像从头到尾连续处理，骨干状态与航迹状态都跨片段延续。
模式：
    train   多流 TBPTT（与 train_stream_v1 的 trainer=streams 同一排法：B 条流、每段 k 窗、片段边界 detach），
            每轮在 val 上同时评估骨干原输出（base）与航迹头输出（track），按 track 的 val IoU 挑最好的一轮
    eval    在 val / test 上评估：四个指标（IoU / ACC / Pd / Fa，与正式评估同一口径）、误差类别（tools/error_budget.py），
            以及事先定好的关口是否通过；可选保存逐事件预测（--dump-dir）与逐窗航迹（--tracks-dir，可视化用）
decision_lag = 1 时：track = 一窗滞后的最终输出（最后一窗没有下一窗，用零等待输出），track_now = 零等待的暂定输出；
    训练损失 = now_loss_weight x 零等待 BCE + lag_loss_weight x 滞后 BCE。
骨干一律用逐层执行（execution=layer）：与逐窗执行数学等价（单元测试已核对），这里只为速度；base 一列即用来核对复现。
用法见 configs/track_head_v2.yaml 文件头。
"""
import os

os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":16:8")   # 必须在导入 torch 之前设置

import argparse  # noqa: E402
import json  # noqa: E402
import math  # noqa: E402
import sys  # noqa: E402
import time  # noqa: E402
from pathlib import Path  # noqa: E402

import numpy as np  # noqa: E402
import torch  # noqa: E402
import torch.nn.functional as F  # noqa: E402

import train_stream_v1 as T  # noqa: E402
from dataset.ev_uav_stream import EvUAVStream  # noqa: E402
from dataset.stream_source import make_window_source  # noqa: E402
from dataset.stream_windows import refill_by_index  # noqa: E402
from model.changepoint_layer import (CHANGEPOINT_KEYS, ChangepointLayer, footprint_statistics,  # noqa: E402
                                     occupancy_boxes, occupancy_maps)
from model.clutter_field import event_count_maps  # noqa: E402
from model.comod import REF_RATE  # noqa: E402
from model.object_layer import OBJECT_KEYS, ObjectLayer, backbone_stride  # noqa: E402
from model.object_tokens import TOKEN_KEYS, ObjectTokenLayer  # noqa: E402
from model.track_head import TrackHead  # noqa: E402
from utils.stream_common import linear_epoch_lr, load_flat_config  # noqa: E402
from utils.stream_metrics import FastRoc  # noqa: E402
from utils.train_numerics import clip_grad_norm_checked_  # noqa: E402

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "tools"))
import error_budget  # noqa: E402

HEAD_KEYS = ("cell", "slots", "hidden", "history", "gate_sigma", "gate_max_px", "gate_floor", "birth_floor",
             "max_births", "death_exist", "max_coast", "match_min_px", "corr_hidden", "r_min", "recycle_exist",
             "decision_lag", "context", "existence", "defer_max", "defer_alpha",
             "defer_revision", "pd_max", "provisional_gate")


# ---------------------------------------------------------------------------
# 骨干与航迹头
# ---------------------------------------------------------------------------


class ReadoutTap(object):
    """截取骨干读出层的输入（逐事件 dec1 特征），不改动骨干代码与输出。"""

    def __init__(self, net):
        self.feat = None
        original = net._readout

        def tapped(feat, events):
            self.feat = feat
            return original(feat, events)

        net._readout = tapped


def load_base(cfg, device):
    """读取冻结的骨干。网络结构、q99、pos_weight 取自骨干 checkpoint；数据根目录与评测口径取自本配置。"""
    ckpt = torch.load(cfg["base_checkpoint"], map_location=device)
    base = T.eval_train_config(ckpt["config"], cfg)
    base["execution"], base["input_device"] = "layer", cfg.get("input_device", "gpu")
    net = T.build_net(base, device)
    net.load_state_dict(ckpt["model"])
    if not bool(net.gain_calibrated):
        raise RuntimeError("骨干 checkpoint 的增益未校准")
    net.eval()
    for p in net.parameters():
        p.requires_grad_(False)
    stats = ckpt["stats"]
    q99 = np.asarray(stats["q99"], dtype=np.float32)
    pos_weight = min(float(stats["train_neg"]) / float(stats["train_pos"]), float(base["pos_weight_cap"]))
    return net, ReadoutTap(net), base, q99, pos_weight, ckpt


def split_dataset(base, split, max_sequences=None):
    """某个划分的录像；max_sequences 给出时只取文件名排序后的前几条（冒烟用）。"""
    dataset = EvUAVStream(base["root"], split, base)
    if max_sequences:
        dataset = EvUAVStream(base["root"], split, base, names=dataset.names[:int(max_sequences)])
    return dataset


def build_head(cfg, net, base, device, q99=None, pos_weight=None):
    """head_kind = track（v2～v4f 的航迹头）、object（v5 目标神经元层，手写滤波程序，作对照）、tokens（v6 目标 token 层，
    网络写法；Inn 13.71）或 changepoint（RCL v1.3 回溯式变点标注层，RCL_V1_PLAN_20261101.md）。
    长度单位 = 骨干总步长，由网络结构读出。changepoint 另需骨干的 q99（输入编码）与正样本权重（p0 的校准）。"""
    feat_dim = int(net.readout[0].in_features) - 2                 # 读出层输入 = [dec1 特征, p, t_local]
    kind = cfg.get("head_kind", "track")
    if kind == "changepoint":
        if q99 is None or pos_weight is None:
            raise ValueError("head_kind = changepoint 需要骨干的 q99 与 pos_weight")
        kwargs = {key: cfg[key] for key in CHANGEPOINT_KEYS if key in cfg}
        if "rings" in kwargs:
            kwargs["rings"] = tuple(int(r) for r in kwargs["rings"])
        return ChangepointLayer(feat_dim, int(base["pad_height"]), int(base["pad_width"]), q99=q99,
                                input_clip=float(base["input_clip"]), time_bins=int(base["time_bins"]),
                                pos_weight=float(pos_weight), threshold=float(base["threshold"]), **kwargs).to(device)
    if kind in ("object", "tokens"):
        keys, cls = (OBJECT_KEYS, ObjectLayer) if kind == "object" else (TOKEN_KEYS, ObjectTokenLayer)
        kwargs = {key: cfg[key] for key in keys if key in cfg}
        if kwargs.get("clutter_source") == "background":        # 模块二的背景率（以模块二的参照率为单位 / 下限）
            kwargs["ref_rate"] = tuple(base.get("invariant_ref_rate", REF_RATE))
        return cls(feat_dim, int(base["pad_height"]), int(base["pad_width"]), length_unit=backbone_stride(net),
                   **kwargs).to(device)
    if kind != "track":
        raise ValueError("head_kind 必须是 track、object 或 tokens")
    kwargs = {key: cfg[key] for key in HEAD_KEYS if key in cfg}
    return TrackHead(feat_dim, int(base["pad_height"]), int(base["pad_width"]), **kwargs).to(device)


# ---------------------------------------------------------------------------
# 多流训练
# ---------------------------------------------------------------------------


def event_background(events):
    """每个事件所在像素、所在极性的背景率（模块二，events["bg"] [T, B, 2, H, W]；通道 0 = ON（p = 1），1 = OFF）。"""
    ch = (events["p"] < 0.5).long()
    return events["bg"][events["t"], events["b"] if "b" in events else torch.zeros_like(events["t"]), ch,
                        events["y"], events["x"]]


class BaseOutputs(object):
    """冻结骨干的逐事件输出缓存：每条录像从头到尾连续推理一次（逐层执行、eval_chunk 窗一段、状态跨段延续），
    把 z0 与 dec1 特征按事件在文件中的下标存起来。

    多流训练里每条录像都从自己的开头起算（keep 在录像开头清零），状态跨片段延续，所以骨干对一条录像的输出与流怎么排、
    开头延迟几窗无关：算一次，各轮复用。这样每轮只剩航迹头的计算（骨干与模块二的背景估计不再重复）。
    """

    def __init__(self, net, tap, base, q99, device, dataset, keep_all=True, with_bg=False, field=None):
        self.net, self.tap, self.base, self.q99, self.device = net, tap, base, q99, device
        self.dataset, self.keep_all, self.with_bg = dataset, keep_all, bool(with_bg)
        self.field = field          # 学出来的杂波场（model/clutter_field.py）：给出时由它算 events["bg"]
        self.items, self.bg_items = {}, {}
        self.dtype = next(net.parameters()).dtype

    def get(self, index):
        if index in self.items:
            return self.items[index]
        seq = self.dataset[index]
        source = make_window_source(seq, self.base, self.q99, self.device, self.dtype)
        z0_all = torch.zeros(seq.n_events, dtype=torch.float32)
        feat_all = None
        chunk = int(self.base.get("eval_chunk", 32))
        states = None
        bg_all = torch.zeros(seq.n_events, dtype=torch.float32) if self.with_bg else None
        fstate = None
        with torch.no_grad():
            for start in range(0, seq.n_windows, chunk):
                end = min(start + chunk, seq.n_windows)
                x, events, _, idx = source.chunk(start, end)
                if self.field is not None:                   # 模块二 v2：背景率由学出来的杂波场给出（因果，状态跨片段）
                    counts = event_count_maps(events, end - start, 1, int(self.base["pad_height"]),
                                              int(self.base["pad_width"]))
                    log_rate, fstate = self.field.forward_chunk(counts, fstate)
                    events = dict(events, bg=torch.exp(log_rate))
                z0, states, _ = self.net.forward_chunk(x, events, states)
                if bg_all is not None:
                    if events.get("bg") is None:
                        raise ValueError("目标层要模块二的背景率，但骨干的输入没有 events['bg']（invariant_input 未开）")
                    bg_all[torch.from_numpy(np.asarray(idx, dtype=np.int64))] = event_background(events).float().cpu()
                feat = self.tap.feat.float().cpu()
                if feat_all is None:
                    feat_all = torch.zeros((seq.n_events, int(feat.shape[1])), dtype=torch.float32)
                index_t = torch.from_numpy(np.asarray(idx, dtype=np.int64))
                z0_all[index_t] = z0.float().cpu()
                feat_all[index_t] = feat
        if feat_all is None:
            feat_all = torch.zeros((seq.n_events, int(self.net.readout[0].in_features) - 2), dtype=torch.float32)
        item = (seq, z0_all, feat_all)
        if self.keep_all:
            self.items[index] = item
        if bg_all is not None:
            if not self.keep_all:
                self.bg_items.clear()
            self.bg_items[index] = bg_all
        return item

    def bg(self, index):
        """第 index 条录像每个事件的背景率（模块二；顺序与文件相同）；没有开 with_bg 时为 None。"""
        return self.bg_items.get(index) if self.with_bg else None


def chunk_events(seq, lo, hi, offset=0, stream=0):
    """录像第 lo..hi-1 窗的事件（与 TorchWindowSource.chunk 同一顺序：先按窗、窗内按时间稳定排序），
    返回 numpy 字典 t（片段内窗号 + offset）/ b / x / y / p / t_local / bin（窗内时间箱）/ label / tid，以及事件在文件中的下标。"""
    a, b = int(seq.bounds[lo]), int(seq.bounds[hi])
    idx = seq.order[a:b]
    window = np.repeat(np.arange(lo, hi, dtype=np.int64), np.diff(seq.bounds[lo:hi + 1]))
    return {"t": window - lo + int(offset), "b": np.full(b - a, stream, dtype=np.int64),
            "x": seq.x[idx].astype(np.int64), "y": seq.y[idx].astype(np.int64),
            "p": seq.p[idx].astype(np.float32), "t_local": seq.t_local[idx].astype(np.float32),
            "bin": seq.inner_bin[idx].astype(np.int64),
            "label": seq.label[idx].astype(np.float32), "tid": seq.target_id[idx].astype(np.float32)}, idx


def to_device(parts, device):
    events = {key: torch.from_numpy(np.ascontiguousarray(parts[key])).to(device)
              for key in ("t", "b", "x", "y", "p", "t_local", "bin") if key in parts}
    return events, torch.from_numpy(parts["label"]).to(device), torch.from_numpy(parts["tid"]).to(device)


def sequence_occupancy(outputs, index, seq, cell, centre=False):
    """每条训练录像的目标轨迹占据框（RCL 的在场标签，model/changepoint_layer.occupancy_boxes），按录像缓存。
    centre = True（RCL v4，state = centre）：每个目标只取外接框中心所在的格。"""
    cache = outputs.__dict__.setdefault("occupancy_cache", {})
    if (index, centre) not in cache:
        cache[(index, centre)] = occupancy_boxes(seq, cell, centre=centre)
    return cache[(index, centre)]


def assemble_cached(outputs, pieces, steps, device, occ_spec=None, centre=False):
    """多流片段：拼接各流的事件与缓存的骨干输出。返回 (events, z0, feat, labels, keep [T, B], tid)。
    occ_spec = (cell, hc, wc) 时另给 events['occ'] [T, B, hc, wc]：目标轨迹占据（RCL 训练用；centre 见 sequence_occupancy）。"""
    batch = len(pieces)
    keep = torch.ones((steps, batch), dtype=torch.float32, device=device)
    cols = {key: [] for key in ("t", "b", "x", "y", "p", "t_local", "bin", "label", "tid")}
    z0s, feats, bgs = [], [], []
    occ = np.zeros((steps, batch, occ_spec[1], occ_spec[2]), dtype=np.float32) if occ_spec else None
    for b, stream in enumerate(pieces):
        for index, lo, hi, offset, new_start in stream:
            seq, z0_all, feat_all = outputs.get(index)
            part, idx = chunk_events(seq, lo, hi, offset, b)
            for key in cols:
                cols[key].append(part[key])
            index_t = torch.from_numpy(np.asarray(idx, dtype=np.int64))
            z0s.append(z0_all[index_t])
            feats.append(feat_all[index_t])
            if getattr(outputs, "with_bg", False):
                bgs.append(outputs.bg(index)[index_t])
            if occ is not None:
                cells = sequence_occupancy(outputs, index, seq, occ_spec[0], centre)
                occ[offset:offset + hi - lo, b] = occupancy_maps(cells, lo, hi, occ_spec[1], occ_spec[2])
            if new_start:
                keep[offset, b] = 0
    if not z0s:
        empty = {key: np.zeros(0, dtype=np.int64 if key in ("t", "b", "x", "y", "bin") else np.float32)
                 for key in cols}
        events, labels, tid = to_device(empty, device)
        if occ is not None:
            events["occ"] = torch.from_numpy(occ).to(device)
        return events, torch.zeros(0, device=device), torch.zeros(0, 1, device=device), labels, keep, tid
    events, labels, tid = to_device({key: np.concatenate(v) for key, v in cols.items()}, device)
    if bgs:
        events["bg_event"] = torch.cat(bgs).to(device)
    if occ is not None:
        events["occ"] = torch.from_numpy(occ).to(device)
    return events, torch.cat(z0s).to(device), torch.cat(feats).to(device), labels, keep, tid


class ParamEMA(object):
    """权重的指数滑动平均（Polyak 平均）：训练照常更新原始权重，评估与保存用平均后的权重。
    衰减 d = 1 - 1 / (窗口轮数 x 每轮更新数)，即"平均最近若干轮"，与数据集大小无关；开头按 d_t = min(d, (1 + t) / (10 + t))
    爬升（TF / YOLO 的做法），避免偏向初值。swap() 把原始权重与平均权重互换，调用两次复原。"""

    def __init__(self, module, decay):
        self.decay, self.steps = float(decay), 0
        self.shadow = {n: p.detach().clone() for n, p in module.named_parameters()}

    def update(self, module):
        self.steps += 1
        d = min(self.decay, (1.0 + self.steps) / (10.0 + self.steps))
        with torch.no_grad():
            for n, p in module.named_parameters():
                self.shadow[n].mul_(d).add_(p.detach(), alpha=1.0 - d)

    def swap(self, module):
        with torch.no_grad():
            for n, p in module.named_parameters():
                tmp = p.detach().clone()
                p.copy_(self.shadow[n])
                self.shadow[n].copy_(tmp)


def ema_for(head, cfg, lengths):
    """cfg["ema_epochs"] > 0 时按"平均最近多少轮"建 ParamEMA；否则 None。每轮更新数 = ceil(总窗数 / (流数 x k))。"""
    window = float(cfg.get("ema_epochs", 0.0) or 0.0)
    if window <= 0.0:
        return None
    per_epoch = max(1, int(math.ceil(sum(lengths) / float(int(cfg["streams"]) * int(cfg["tbptt_k"])))))
    return ParamEMA(head, 1.0 - 1.0 / (window * per_epoch))


def train_epoch(outputs, head, lengths, optimizer, cfg, pos_weight, device, rng, max_chunks=None, ema=None):
    k, n_streams = int(cfg["tbptt_k"]), int(cfg["streams"])
    if cfg.get("stream_layout", "greedy") != "greedy":
        raise ValueError("骨干输出缓存要求每条录像整段放进一条流（stream_layout = greedy）")
    plan = T.plan_streams(lengths, n_streams, k, rng, "greedy")
    n_chunks = int(math.ceil(T.stream_total_windows(plan) / float(k)))
    if max_chunks is not None:
        n_chunks = min(n_chunks, int(max_chunks))
    weight = torch.tensor([pos_weight], dtype=torch.float32, device=device)
    lam_e, lam_p, clip = float(cfg["lambda_exist"]), float(cfg["lambda_pos"]), float(cfg["grad_clip"])
    lam_d, lam_o = float(cfg.get("lambda_pd", 1.0)), float(cfg.get("lambda_origin", 1.0))   # 只在 existence = ipda 时有项
    lam_m = float(cfg.get("lambda_membership", 1.0))                    # 只在门控修正（defer_revision = gated）时有项
    lam_v = float(cfg.get("lambda_event", 1.0))                         # RCL：各滞后的事件输出（L_evt）
    lam_y = float(cfg.get("lambda_dynamics", 0.0))                      # RCL v2：标签占据上的转移损失（L_dyn）
    w_now, w_lag = float(cfg.get("now_loss_weight", 1.0)), float(cfg.get("lag_loss_weight", 1.0))
    lag = head.has_delayed                                              # 一窗滞后或目标级延迟决策：都有终判输出
    occ_spec = getattr(head, "occupancy_spec", None)                    # RCL：在场标签（目标轨迹占据）
    extra = (occ_spec, getattr(head, "state", "box") == "centre") if occ_spec else ()
    sums = {"event": 0.0, "events": 0, "lag": 0.0, "lag_n": 0, "exist": 0.0, "exist_n": 0, "pos": 0.0, "pos_n": 0,
            "pd": 0.0, "pd_n": 0, "org": 0.0, "org_n": 0, "mem": 0.0, "mem_n": 0, "evt": 0.0, "evt_n": 0,
            "dyn": 0.0, "dyn_n": 0,
            "updates": 0, "births": 0, "recycled": 0, "live": 0, "slot_windows": 0}
    norms = []
    hstate = None
    head.train()
    for c in range(n_chunks):
        pieces = T.stream_pieces(plan, c * k, (c + 1) * k)
        events, z0, feat, labels, keep, tid = assemble_cached(outputs, pieces, k, device, *extra)
        z, hstate, aux = head.forward_chunk(events, z0, feat, hstate, k, keep=keep, labels=labels, tid=tid,
                                            keys=labels if lag else None)
        for key in ("births", "recycled", "live", "slot_windows"):
            sums[key] += aux[key]
        if labels.numel():
            n_ev = int(labels.numel())
            ev_loss = F.binary_cross_entropy_with_logits(z, labels, pos_weight=weight, reduction="sum") / n_ev
            loss = w_now * ev_loss if lag else ev_loss
            if lag and aux["delayed_z"] is not None:
                n_lag = int(aux["delayed_z"].shape[0])
                lag_loss = F.binary_cross_entropy_with_logits(aux["delayed_z"], aux["delayed_key"], pos_weight=weight,
                                                              reduction="sum") / n_lag
                loss = loss + w_lag * lag_loss
                sums["lag"] += float(lag_loss.detach()) * n_lag
                sums["lag_n"] += n_lag
            if aux["exist_n"]:
                loss = loss + lam_e * aux["exist_sum"] / aux["exist_n"]
            if aux["pos_n"]:
                loss = loss + lam_p * aux["pos_sum"] / aux["pos_n"]
            if aux["pd_n"]:
                loss = loss + lam_d * aux["pd_sum"] / aux["pd_n"]
            if aux["org_n"]:
                loss = loss + lam_o * aux["org_sum"] / aux["org_n"]
            if aux["mem_n"]:
                loss = loss + lam_m * aux["mem_sum"] / aux["mem_n"]
            if aux.get("evt_n"):
                loss = loss + lam_v * aux["evt_sum"] / aux["evt_n"]
            if lam_y > 0.0 and aux.get("dyn_n"):
                loss = loss + lam_y * aux["dyn_sum"] / aux["dyn_n"]
            if not math.isfinite(float(loss.detach())):
                raise RuntimeError("损失出现非有限值：片段 %d" % c)
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            norms.append(clip_grad_norm_checked_(head.named_parameters(), clip, "head chunk %d" % c))
            optimizer.step()
            if ema is not None:
                ema.update(head)
            sums["event"] += float(ev_loss.detach()) * n_ev
            sums["events"] += n_ev
            sums["exist"] += float(aux["exist_sum"].detach())
            sums["exist_n"] += aux["exist_n"]
            sums["pos"] += float(aux["pos_sum"].detach())
            sums["pos_n"] += aux["pos_n"]
            for key in ("pd", "org", "mem"):
                sums[key] += float(aux[key + "_sum"].detach())
                sums[key + "_n"] += aux[key + "_n"]
            if aux.get("evt_n"):
                sums["evt"] += float(aux["evt_sum"].detach())
                sums["evt_n"] += aux["evt_n"]
            if aux.get("dyn_n"):
                sums["dyn"] += float(aux["dyn_sum"].detach())
                sums["dyn_n"] += aux["dyn_n"]
            sums["updates"] += 1
        hstate = head.detach_state(hstate)
    windows = max(sums["slot_windows"], 1)
    return {"event_loss": sums["event"] / max(sums["events"], 1),
            "lag_loss": sums["lag"] / max(sums["lag_n"], 1) if lag else None,
            "exist_loss": sums["exist"] / max(sums["exist_n"], 1),
            "pos_loss": sums["pos"] / max(sums["pos_n"], 1),
            "pd_loss": sums["pd"] / sums["pd_n"] if sums["pd_n"] else None,
            "origin_loss": sums["org"] / sums["org_n"] if sums["org_n"] else None,
            "membership_loss": sums["mem"] / sums["mem_n"] if sums["mem_n"] else None,
            "event_lag_loss": sums["evt"] / sums["evt_n"] if sums["evt_n"] else None,
            "dynamics_loss": sums["dyn"] / sums["dyn_n"] if sums["dyn_n"] else None,
            "updates": sums["updates"], "chunks": n_chunks,
            "grad_norm_median": float(np.median(norms)) if norms else 0.0,
            "births_per_window": sums["births"] / windows, "recycled_per_window": sums["recycled"] / windows,
            "live_per_window": sums["live"] / windows}


# ---------------------------------------------------------------------------
# 评估
# ---------------------------------------------------------------------------


def run_split(outputs, head, base, device, split, full=False, dump_dir=None, tracks_dir=None, cache=None):
    """整段连续推理一个划分；返回 base（骨干原输出）、track（航迹头最终输出）的指标，滞后判决时另有 track_now（零等待）。

    cache（训练中每轮验证用的字典，跨轮保留）：骨干冻结，base 的计数与误差类别每轮都一样，只在第一轮算一次；
    给出 cache 时 track_now 只算 IoU、不做误差分类（省时间）。正式评估（mode_eval）不传 cache，全部都算。
    """
    dataset = outputs.dataset
    thr = float(base["threshold"])
    chunk = int(base.get("eval_chunk", 32))
    lag = head.has_delayed
    kinds = ("base", "track", "track_now") if lag else ("base", "track")
    counts = {kind: np.zeros(3, dtype=np.int64) for kind in kinds}                   # TP, FP, FN
    rocs = {kind: FastRoc(base["pd_detT"], base["correct_thresh"], base["height"], base["width_px"])
            for kind in kinds} if full else None
    rows = {kind: [] for kind in kinds}
    stats = {"births": 0, "recycled": 0, "live": 0, "slot_windows": 0}
    delays, dstat, n_events, n_target, t_delays = [], np.zeros(5, dtype=np.int64), 0, 0, []
    flips = {"up_tp": 0, "up_fp": 0, "down_tn": 0, "down_fn": 0}
    rescued_wait = []
    was_training = head.training
    head.eval()
    with torch.no_grad():
        for i in range(len(dataset)):
            seq, z0_all, feat_all = outputs.get(i)
            bg_all = outputs.bg(i) if getattr(outputs, "with_bg", False) else None
            hstate = head.init_state(1, device)
            idx_parts, p0_parts, p1_parts, lag_key, lag_prob = [], [], [], [], []
            seq_wait, seq_status = [], []                          # 延迟决策：每个终判事件等了几窗、终判状态
            log = [] if tracks_dir else None
            for start in range(0, seq.n_windows, chunk):
                end = min(start + chunk, seq.n_windows)
                part, idx = chunk_events(seq, start, end)
                events, _, _ = to_device(part, device)
                index_t = torch.from_numpy(np.asarray(idx, dtype=np.int64))
                z0, feat = z0_all[index_t].to(device), feat_all[index_t].to(device)
                if bg_all is not None:
                    events["bg_event"] = bg_all[index_t].to(device)
                keys = index_t.to(device) if lag else None
                z, hstate, aux = head.forward_chunk(events, z0, feat, hstate, end - start, log=log, keys=keys)
                for key in stats:
                    stats[key] += aux[key]
                idx_parts.append(idx)
                p0_parts.append(torch.sigmoid(z0).float().cpu().numpy())
                p1_parts.append(torch.sigmoid(z).float().cpu().numpy())
                if lag and aux["delayed_z"] is not None:
                    lag_key.append(aux["delayed_key"].cpu().numpy().astype(np.int64))
                    lag_prob.append(torch.sigmoid(aux["delayed_z"]).float().cpu().numpy())
                    if aux.get("delayed_lag") is not None:
                        lk = lag_key[-1]
                        lw = aux["delayed_lag"].cpu().numpy().astype(np.int64)
                        ls = aux["delayed_status"].cpu().numpy().astype(np.int64)
                        delays.append(lw)
                        t_delays.append(lw[seq.label[lk] > 0.5])
                        dstat += np.bincount(ls, minlength=5)
                        seq_wait.append(lw)
                        seq_status.append(ls)
            if hasattr(head, "flush"):                        # RCL：录像结束时把仍在等待的事件提交完（状态 3）
                fl = head.flush(hstate)
                if fl["delayed_z"] is not None:
                    lag_key.append(fl["delayed_key"].cpu().numpy().astype(np.int64))
                    lag_prob.append(torch.sigmoid(fl["delayed_z"]).float().cpu().numpy())
                    lw = fl["delayed_lag"].cpu().numpy().astype(np.int64)
                    ls = fl["delayed_status"].cpu().numpy().astype(np.int64)
                    delays.append(lw)
                    t_delays.append(lw[seq.label[lag_key[-1]] > 0.5])
                    dstat += np.bincount(ls, minlength=5)
                    seq_wait.append(lw)
                    seq_status.append(ls)
            probs = {"base": refill_by_index(seq.n_events, idx_parts, p0_parts),
                     "track": refill_by_index(seq.n_events, idx_parts, p1_parts)}
            if lag:
                probs["track_now"] = probs["track"].copy()
                if lag_key:                                   # 最后一窗没有下一窗：保留零等待输出
                    probs["track"][np.concatenate(lag_key)] = np.concatenate(lag_prob)
            pos = seq.label > 0.5
            n_events += int(seq.n_events)
            n_target += int(pos.sum())
            if lag:                                           # 输出被改动的事件：往上 / 往下，改对 / 改错
                now_on, fin_on = probs["track_now"] >= thr, probs["track"] >= thr
                up, down = ~now_on & fin_on, now_on & ~fin_on
                flips["up_tp"] += int((up & pos).sum())
                flips["up_fp"] += int((up & ~pos).sum())
                flips["down_tn"] += int((down & ~pos).sum())
                flips["down_fn"] += int((down & pos).sum())
                if head.defer_max and seq_wait:               # 被未来救回的目标事件（暂定 0、终判 1、真目标）等了几窗
                    wait = np.full(seq.n_events, -1, dtype=np.int64)
                    wait[np.concatenate(lag_key)] = np.concatenate(seq_wait)
                    rescued_wait.append(wait[up & pos])
            for kind in kinds:
                prob = probs[kind]
                cached = cache is not None and kind == "base" and seq.name in cache
                if cached:
                    count, row = cache[seq.name]
                else:
                    pred = prob >= thr
                    count = np.array([int((pred & pos).sum()), int((pred & ~pos).sum()), int((~pred & pos).sum())])
                    row = None
                    if cache is None or kind != "track_now":
                        row = error_budget.analyse_arrays(
                            seq.name, seq.x, seq.y, seq.t, pos, prob, seq.target_id, thr, 10, float(base["window_ms"]),
                            (1,), int(base["height"]), int(base["width_px"]))[0]
                    if cache is not None and kind == "base":
                        cache[seq.name] = (count, row)
                counts[kind] += count
                if full:
                    rocs[kind].update(seq.t, prob, seq.target_id, seq.label, seq.x, seq.y, thr)
                if row is not None:
                    rows[kind].append(row)
            if dump_dir:
                extra = {"now_probabilities": probs["track_now"].astype(np.float32)} if lag else {}
                if head.defer_max:
                    # 每个事件的判决延迟（窗，-1 = 当窗终判）与终判状态（0 确认 1 否定 2 重新捕获 3 丢失 4 强制，-1 = 未延后）
                    wait = np.full(seq.n_events, -1, dtype=np.int8)
                    status = np.full(seq.n_events, -1, dtype=np.int8)
                    if seq_wait:
                        keys_all = np.concatenate(lag_key)
                        wait[keys_all] = np.concatenate(seq_wait)
                        status[keys_all] = np.concatenate(seq_status)
                    extra.update(decision_wait=wait, decision_status=status)
                np.savez(os.path.join(dump_dir, seq.name),
                         locs=np.stack([np.zeros(seq.n_events, dtype=np.int64), seq.x, seq.y, seq.t], 1),
                         labels=seq.label.astype(np.float32), probabilities=probs["track"].astype(np.float32),
                         base_probabilities=probs["base"].astype(np.float32),
                         target_id=seq.target_id.astype(np.float64), **extra)
            if tracks_dir and log:                            # every per-window field the head logs (active / pos / ...)
                np.savez(os.path.join(tracks_dir, seq.name),
                         **{key: np.stack([w[key][0] for w in log]) for key in log[0]})
    head.train(was_training)
    windows = max(stats["slot_windows"], 1)
    out = {"split": split, "n_sequences": len(dataset),
           "head_stats": {"births_per_window": stats["births"] / windows,
                          "recycled_per_window": stats["recycled"] / windows,
                          "live_per_window": stats["live"] / windows}}
    if head.defer_max:
        dl = np.concatenate(delays) if delays else np.zeros(0, dtype=np.int64)
        tl = np.concatenate(t_delays) if t_delays else np.zeros(0, dtype=np.int64)
        out["head_stats"].update(
            deferred_frac=float(dl.size) / max(n_events, 1), target_deferred_frac=float(tl.size) / max(n_target, 1),
            mean_delay_windows=float(dl.sum()) / max(n_events, 1),
            target_mean_delay_windows=float(tl.sum()) / max(n_target, 1),
            deferred_p95_windows=float(np.percentile(dl, 95)) if dl.size else 0.0,
            status={name: int(c) for name, c in zip(getattr(head, "status_names", (
                "confirmed", "rejected", "reacquired", "lost", "forced")), dstat)})
        rw = np.concatenate(rescued_wait) if rescued_wait else np.zeros(0, dtype=np.int64)
        out["head_stats"].update(
            rescued_targets=int(rw.size), rescued_mean_wait_windows=float(rw.mean()) if rw.size else None,
            rescued_full_wait_frac=float((rw >= head.defer_max).mean()) if rw.size else None)
    if lag:
        out["head_stats"]["flips"] = dict(flips)
    for kind, (tp, fp, fn) in counts.items():
        res = {"iou": tp / max(tp + fp + fn, 1), "acc": tp / max(tp + fn, 1), "tp": int(tp), "fp": int(fp),
               "fn": int(fn)}
        if full:
            pd, fa = rocs[kind].result()
            res.update(pd=float(pd), fa=float(fa))
        if rows[kind]:
            res["fp_cat"] = {c: sum(r["fp_cat"][c] for r in rows[kind]) for c in ("near", "tail", "ahead", "far")}
            res["fn_cat"] = {c: sum(r["fn_cat"][c] for r in rows[kind]) for c in ("never", "same", "onset", "gap")}
        out[kind] = res
    return out


def gate_check(result, cfg):
    """事先定好的关口（13.60）：拖尾误报、断续漏检各降 >= gate_tail_drop / gate_gap_drop；IoU 不低于 base；
    目标附近的误报增加 <= gate_near_rise。"""
    b, t = result["base"], result["track"]

    def drop(before, after):
        return (before - after) / float(before) if before else 0.0

    checks = {
        "tail_fp_drop": drop(b["fp_cat"]["tail"], t["fp_cat"]["tail"]),
        "gap_fn_drop": drop(b["fn_cat"]["gap"], t["fn_cat"]["gap"]),
        "iou_delta": t["iou"] - b["iou"],
        "near_fp_rise": -drop(b["fp_cat"]["near"], t["fp_cat"]["near"]),
    }
    checks["pass"] = bool(checks["tail_fp_drop"] >= float(cfg["gate_tail_drop"])
                          and checks["gap_fn_drop"] >= float(cfg["gate_gap_drop"])
                          and checks["iou_delta"] >= 0.0
                          and checks["near_fp_rise"] <= float(cfg["gate_near_rise"]))
    return checks


# ---------------------------------------------------------------------------
# 模式
# ---------------------------------------------------------------------------


def needs_background(head):
    """目标层的杂波强度取模块二的背景率时，骨干输出缓存要同时存每个事件的背景率。"""
    return getattr(head, "clutter_source", None) == "background"


def mean_target_events(dataset):
    """训练集上每个标注目标每窗的平均事件数（目标神经元层期望事件数的初值，一次最大似然估计）。"""
    total = count = 0
    for i in range(len(dataset)):
        seq = dataset[i]
        idx = seq.order[int(seq.bounds[0]):int(seq.bounds[seq.n_windows])]       # same order as chunk_events
        win = np.repeat(np.arange(seq.n_windows, dtype=np.int64), np.diff(seq.bounds[:seq.n_windows + 1]))
        lab = seq.label[idx] > 0.5
        tid = seq.target_id[idx].astype(np.int64)
        sel = lab & (tid > 0)
        if sel.any():
            _, counts = np.unique(win[sel] * 1000003 + tid[sel], return_counts=True)
            total += int(counts.sum())
            count += int(counts.size)
    return total / float(count) if count else 1.0


def load_crossfit_outputs(outputs, path):
    """RCL v4.1：训练录像的骨干输出换成交叉拟合的样本外输出（tools/export_oof_outputs.py；堆叠泛化：判决层要学骨干在
    没见过的录像上的错误，样本内输出里骨干几乎不漏整个目标）。每条训练录像都必须有、事件数必须一致；返回清单。"""
    blob = torch.load(path, map_location="cpu")
    table = blob["outputs"]
    names = outputs.dataset.names
    missing = [n for n in names if n not in table]
    if missing:
        raise RuntimeError("样本外输出缺这些训练录像：%s" % missing[:5])
    for i, name in enumerate(names):
        seq = outputs.dataset[i]
        z0, feat = table[name]
        if int(z0.shape[0]) != int(seq.n_events) or int(feat.shape[0]) != int(seq.n_events):
            raise RuntimeError("%s 的样本外输出事件数 %d 与录像 %d 不一致" % (name, int(z0.shape[0]), int(seq.n_events)))
        outputs.items[i] = (seq, z0.float(), feat.float())
    return blob.get("manifest", {})


def fit_dynamics(head, occs, device, steps, lr=0.05, seed=0):
    """RCL v3：出生 rho、存活 p、位移核 pi 按训练集的标签占据做最大似然（有监督 HMM 的标准做法：状态已知时转移参数
    直接由标签估计），在训练证据之前拟合好。factor_training 下这三个量本来就只由 L_dyn 训练，先拟合与边训边拟合是
    同一个目标；不先拟合时位移核要几千步才离开均匀初值（v2 第 0 轮"不动" 0.04、第 47 轮 0.36），这期间回溯在场
    每往回一窗乘 p x pi_o ~ 0.03，第一拍抬不起来。occs：每条训练录像的占据 [T, hc, wc]（occupancy_maps）。
    每步取一条录像的全部相邻窗对、Adam。返回拟合前后的 L_dyn（每格平均）与学到的量。"""
    occs = [o for o in occs if int(o.shape[0]) >= 2]
    if not occs:
        raise ValueError("没有可用于拟合转移参数的占据序列")
    params = [head.rho_raw, head.p_raw, head.pi_logit]
    opt = torch.optim.Adam(params, lr=lr)
    rng = np.random.RandomState(seed)

    def loss_of(o):
        o = o.to(device)
        return head.transition_loss(o[:-1], o[1:], head.kernel()).mean()

    def mean_loss():
        with torch.no_grad():
            return float(np.mean([float(loss_of(o)) for o in occs]))

    before = mean_loss()
    for _ in range(int(steps)):
        loss = loss_of(occs[rng.randint(len(occs))])
        opt.zero_grad(set_to_none=True)
        loss.backward()
        opt.step()
    head.zero_grad(set_to_none=True)
    return dict(dyn_loss_before=before, dyn_loss_after=mean_loss(), steps=int(steps), **head.evidence_summary())


def head_evidence(head):
    """证据修正（v4e）的参数：kappa = [存在未定, 缺口, 孤儿] 三个证据传递系数（理论值 1），
    orphan_ref = 孤儿事件的参照（新生目标的先验对数几率）；其他修正方式返回 None。
    目标神经元层（v5）：orphan_ref = 新生目标的先验 l0，另有似然比尺度 llr_scale（理论 1）与杂波增益 clutter_gain。"""
    if hasattr(head, "evidence_summary"):
        return head.evidence_summary()
    if getattr(head, "kappa_raw", None) is None:
        return None
    return {"kappa": [float(k) for k in F.softplus(head.kappa_raw.detach()).cpu()],
            "orphan_ref": float(head.orphan_ref.detach())}


def mode_train(args, cfg):
    device = torch.device(args.device)
    T.seed_everything(int(cfg["seed"]), bool(cfg["deterministic"]))
    net, tap, base, q99, pos_weight, _ = load_base(cfg, device)
    head = build_head(cfg, net, base, device, q99=q99, pos_weight=pos_weight)
    root = Path(cfg["save_root"])
    root.mkdir(parents=True, exist_ok=True)
    metrics_path = root / "metrics.jsonl"
    if metrics_path.exists():
        raise RuntimeError("输出目录已有 metrics.jsonl，请换目录")
    T.write_json(root / "run_config.json", cfg)
    optimizer = torch.optim.Adam(head.parameters(), lr=float(cfg["lr"]))
    train_set = split_dataset(base, "train", args.max_sequences)
    lengths = [int(train_set[i].n_windows) for i in range(len(train_set))]
    if hasattr(head, "init_rate"):                                    # 目标神经元层：期望事件数的初值取训练集统计
        rate0 = mean_target_events(train_set)
        head.init_rate(rate0)
        print("目标神经元层：期望事件数初值 %.2f（训练集每个目标每窗的平均事件数）| 长度单位 %.0f px（骨干总步长）"
              % (rate0, head.unit), flush=True)
    bg = needs_background(head)
    train_out = BaseOutputs(net, tap, base, q99, device, train_set, with_bg=bg)
    if cfg.get("train_outputs"):                                      # RCL v4.1: cross-fitted backbone outputs
        if bg:
            raise ValueError("train_outputs（样本外骨干输出）不含模块二的背景率")
        manifest = load_crossfit_outputs(train_out, cfg["train_outputs"])
        T.write_json(root / "train_outputs_manifest.json", manifest)
        print("训练录像用交叉拟合的样本外骨干输出：%s（%d 折）；验证 / 测试用完整骨干" % (
            cfg["train_outputs"], len(manifest.get("folds", []))), flush=True)
    centre = getattr(head, "state", "box") == "centre"
    if cfg.get("label_init") and hasattr(head, "init_from_labels"):   # RCL v4：足迹与期望事件数按标签初始化
        size = 2 * int(head.foot_radius) + 1
        hist, n_ev, n_c = np.zeros((size, size)), 0, 0
        for i in range(len(train_set)):
            h, e, c = footprint_statistics(train_set[i], head.cell, head.foot_radius)
            hist, n_ev, n_c = hist + h, n_ev + e, n_c + c
        init = head.init_from_labels(hist, n_ev, n_c)
        T.write_json(root / "label_init.json", dict(init, footprint=hist.tolist(), target_events=n_ev, centres=n_c))
        print("扩展目标模型按标签初始化：每个目标每窗 %.2f 个事件 | 足迹峰值 %.3f | 半径内的目标事件 %.3f" % (
            init["target_events_per_window"], init["footprint_peak"], init["footprint_inside"]), flush=True)
    prefit = int(cfg.get("dynamics_prefit_steps", 0))
    if prefit > 0:                                                    # RCL v3：转移参数先按标签做最大似然
        cell, hc, wc = head.occupancy_spec
        occs = [torch.from_numpy(occupancy_maps(sequence_occupancy(train_out, i, train_set[i], cell, centre), 0,
                                                int(lengths[i]), hc, wc)) for i in range(len(train_set))]
        fit = fit_dynamics(head, occs, device, prefit)
        T.write_json(root / "dynamics_prefit.json", fit)
        print("转移参数预拟合（标签最大似然，%d 步）：L_dyn %.5f -> %.5f | 存活 %.3f（寿命 %.1f 窗）出生 %.1e | 各环 %s" % (
            prefit, fit["dyn_loss_before"], fit["dyn_loss_after"], fit["survival"], fit["mean_life_windows"],
            fit["birth"], {k: round(v, 3) for k, v in fit["move_prob_by_ring"].items()}), flush=True)
    val_out = BaseOutputs(net, tap, base, q99, device, split_dataset(base, "val", args.max_sequences), with_bg=bg)
    seed, epochs = int(cfg["seed"]), int(cfg["epochs"])
    ema = ema_for(head, cfg, lengths)                                 # after the label init / dynamics pre-fit
    if ema is not None:
        print("权重指数滑动平均：平均最近 %.2f 轮（衰减 %.5f），评估与保存用平均后的权重" % (
            float(cfg["ema_epochs"]), ema.decay), flush=True)
    print("航迹头训练：骨干 %s（冻结）| 航迹头参数 %d | context %s | decision_lag %d | %d 条流、k=%d | "
          "训练集 %d 条录像 %d 窗 | pos_weight %.2f" % (
              cfg["base_checkpoint"], sum(p.numel() for p in head.parameters()), head.context, head.decision_lag,
              int(cfg["streams"]), int(cfg["tbptt_k"]), len(lengths), sum(lengths), pos_weight), flush=True)
    best, val_cache = -float("inf"), {}
    for epoch in range(epochs):
        lr = linear_epoch_lr(epoch, epochs, float(cfg["lr"]), float(cfg["lr_end"]))
        for group in optimizer.param_groups:
            group["lr"] = lr
        if device.type == "cuda":
            torch.cuda.reset_peak_memory_stats(device)
        t0 = time.perf_counter()
        out = train_epoch(train_out, head, lengths, optimizer, cfg, pos_weight, device,
                          np.random.RandomState(seed * 1000 + epoch + 7), args.max_chunks, ema=ema)
        train_s = time.perf_counter() - t0
        if ema is not None:                                           # evaluate / save the averaged weights
            ema.swap(head)
        val = run_split(val_out, head, base, device, "val", cache=val_cache)
        record = dict(epoch=epoch, lr=lr, train=out, val=val, gate=gate_check(val, cfg), train_seconds=train_s,
                      epoch_seconds=time.perf_counter() - t0, peak_memory_gib=T.peak_memory_gib(device),
                      evidence=head_evidence(head))
        with metrics_path.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(record) + "\n")
        state = {"head": head.state_dict(), "epoch": epoch, "val": val, "config": cfg}
        if val["track"]["iou"] > best:
            best = val["track"]["iou"]
            torch.save(dict(state, best_val_iou=best), str(root / ("best_val_iou_seed%d.pt" % seed)))
        torch.save(dict(state, best_val_iou=best), str(root / "last.pt"))
        if ema is not None:                                           # back to the raw weights for training
            ema.swap(head)
        b, t = val["base"], val["track"]
        now = (" | 零等待 IoU %.4f" % val["track_now"]["iou"]) if "track_now" in val else ""
        hs = val["head_stats"]
        if "deferred_frac" in hs:                                     # 延迟决策：多少事件延后终判、目标事件平均等几窗
            now += " | 延后终判 %.2f%%（目标事件 %.1f%%，平均 %.3f 窗）" % (
                100.0 * hs["deferred_frac"], 100.0 * hs["target_deferred_frac"], hs["target_mean_delay_windows"])
        calib = "" if out["pd_loss"] is None else " 检测 %.4f 来源 %.4f" % (out["pd_loss"], out["origin_loss"] or 0.0)
        if out["membership_loss"] is not None:
            calib += " 归属 %.4f" % out["membership_loss"]
        if out.get("event_lag_loss") is not None:                      # RCL：各滞后的事件输出
            calib += " 终判 %.4f" % out["event_lag_loss"]
        if out.get("dynamics_loss") is not None:                       # RCL v2：标签占据上的转移损失
            calib += " 动态 %.5f" % out["dynamics_loss"]
        ev_rec = record["evidence"]
        if ev_rec is not None:                                        # 证据修正（v4e）：证据传递系数 + 孤儿参照
            if ev_rec.get("kappa"):
                calib += " kappa %s" % "/".join("%.2f" % k for k in ev_rec["kappa"])
            if "orphan_ref" in ev_rec:
                calib += " l0 %.2f" % ev_rec["orphan_ref"]
            if "llr_scale" in ev_rec:                                  # 目标神经元层：似然比尺度 w_L（理论 1）
                calib += " wL %.3f" % ev_rec["llr_scale"]
            if "survival" in ev_rec:                                   # RCL：存活、出生、沉默代价、不动的概率
                calib += " 存活 %.3f（寿命 %.1f 窗）出生 %.1e 沉默 %.2f 不动 %.2f" % (
                    ev_rec["survival"], ev_rec["mean_life_windows"], ev_rec["birth"], ev_rec["silence_cost"],
                    ev_rec["move_prob_by_ring"].get(0, 0.0))
            if "obs_bias" in ev_rec:                                   # RCL v3：骨干标记泊松证据的 beta、本格增益
                calib += " beta %.2f 增益 %.2f" % (ev_rec["obs_bias"], ev_rec["obs_gain"])
                if "obs_gain_sum" in ev_rec:                           # RCL v4.1：独立求和通道的增益（稳健通道 = 增益）
                    calib += " 求和增益 %.2f" % ev_rec["obs_gain_sum"]
            if "att_slope" in ev_rec:                                  # RCL v4：归属的 z0 斜率、未检出项、足迹
                calib += " 归属 a %.2f c %.2f 未检出 %.2f 足迹中心 %.2f 最大 %.2f" % (
                    ev_rec["att_slope"], ev_rec["att_bias"], ev_rec["att_undetected"], ev_rec["att_foot_centre"],
                    ev_rec["att_foot_max"])
        if "rescued_targets" in hs:                                   # RCL：被未来救回的目标事件
            now += " | 救回目标事件 %d（平均等 %s 窗，等满 %s）" % (
                hs["rescued_targets"],
                "%.2f" % hs["rescued_mean_wait_windows"] if hs["rescued_mean_wait_windows"] is not None else "-",
                "%.0f%%" % (100 * hs["rescued_full_wait_frac"]) if hs["rescued_full_wait_frac"] is not None else "-")
        print("epoch %d lr %.2e | 损失 事件 %.4f%s 存在 %.4f 位置 %.4f%s | val IoU base %.4f -> track %.4f%s | "
              "拖尾误报 %d -> %d 断续漏检 %d -> %d 目标附近误报 %d -> %d | 每窗 航迹 %.2f 出生 %.3f 回收 %.4f | "
              "%.0fs（训练 %.0fs）| 显存峰值 %.2f GiB" % (
                  epoch, lr, out["event_loss"], (" 滞后 %.4f" % out["lag_loss"]) if out["lag_loss"] is not None else "",
                  out["exist_loss"], out["pos_loss"], calib, b["iou"], t["iou"], now,
                  b["fp_cat"]["tail"], t["fp_cat"]["tail"], b["fn_cat"]["gap"], t["fn_cat"]["gap"],
                  b["fp_cat"]["near"], t["fp_cat"]["near"], val["head_stats"]["live_per_window"],
                  val["head_stats"]["births_per_window"], val["head_stats"]["recycled_per_window"],
                  record["epoch_seconds"], train_s, record["peak_memory_gib"] or 0.0), flush=True)
    print("TRAINING FINISHED:", root, flush=True)


def fit_existence_temperature(cfg, net, tap, base, q99, head, device):
    """在 val 上拟合存在对数几率的温度 T（Guo 2017 的温度缩放，只有一个参数）：min_T BCE(sigmoid(L / T), y)。
    y = 该航迹窗是否匹配上标注目标（与训练时的存在监督同一口径）。只用于停止规则：|L| / T >= A 等价于 |L| >= A T。"""
    dataset = EvUAVStream(base["root"], "val", base)
    outputs = BaseOutputs(net, tap, base, q99, device, dataset, keep_all=False, with_bg=needs_background(head))
    chunk = int(base.get("eval_chunk", 32))
    logits, targets = [], []
    head.eval()
    head.collect_calibration = True
    with torch.no_grad():
        for i in range(len(dataset)):
            seq, z0_all, feat_all = outputs.get(i)
            hstate = head.init_state(1, device)
            for start in range(0, seq.n_windows, chunk):
                end = min(start + chunk, seq.n_windows)
                part, idx = chunk_events(seq, start, end)
                events, labels, tid = to_device(part, device)
                index_t = torch.from_numpy(np.asarray(idx, dtype=np.int64))
                keys = index_t.to(device) if head.has_delayed else None
                _, hstate, aux = head.forward_chunk(events, z0_all[index_t].to(device), feat_all[index_t].to(device),
                                                    hstate, end - start, labels=labels, tid=tid, keys=keys)
                for lg, tg in aux.get("calib", []):
                    logits.append(lg.float().cpu())
                    targets.append(tg.float().cpu())
    head.collect_calibration = False
    L, y = torch.cat(logits), torch.cat(targets)
    grid = torch.exp(torch.linspace(math.log(0.5), math.log(5.0), 91))
    losses = torch.stack([F.binary_cross_entropy_with_logits(L / t, y) for t in grid])
    best = int(torch.argmin(losses))
    one = int(torch.argmin(torch.abs(grid - 1.0)))
    alpha = float(cfg.get("defer_alpha") or 0.05)
    hi, hi_t = torch.sigmoid(L) >= 1.0 - alpha, torch.sigmoid(L / grid[best]) >= 1.0 - alpha
    return {"temperature": float(grid[best]), "n": int(y.numel()), "bce_before": float(losses[one]),
            "bce_after": float(losses[best]),
            "precision_at_confirm_before": float(y[hi].mean()) if bool(hi.any()) else None,
            "precision_at_confirm_after": float(y[hi_t].mean()) if bool(hi_t.any()) else None}


def mode_eval(args, cfg):
    device = torch.device(args.device)
    T.seed_everything(int(cfg["seed"]), bool(cfg["deterministic"]))
    net, tap, base, q99, pos_weight, _ = load_base(cfg, device)
    head = build_head(cfg, net, base, device, q99=q99, pos_weight=pos_weight)
    ckpt = torch.load(args.checkpoint, map_location=device)
    head.load_state_dict(ckpt["head"])
    calib = None
    if head.defer_max and cfg.get("calibrate_existence"):
        # 停止规则用校准过的存在后验（D14）：温度只在 val 上拟合，存一份，test 直接读
        cpath = Path(args.checkpoint).parent / ("existence_temperature_%s.json" % Path(args.checkpoint).stem)
        if cpath.exists():
            calib = json.loads(cpath.read_text(encoding="utf-8"))
        else:
            calib = fit_existence_temperature(cfg, net, tap, base, q99, head, device)
            T.write_json(cpath, calib)
        if math.isfinite(head.defer_A):
            head.defer_A = head.defer_A * calib["temperature"]
        print("存在后验温度校准（val 拟合）：", json.dumps(calib, ensure_ascii=False), flush=True)
    for d in (args.dump_dir, args.tracks_dir):
        if d:
            os.makedirs(d, exist_ok=True)
    outputs = BaseOutputs(net, tap, base, q99, device, split_dataset(base, args.split, args.max_sequences),
                          keep_all=False, with_bg=needs_background(head))
    result = run_split(outputs, head, base, device, args.split, full=True, dump_dir=args.dump_dir,
                       tracks_dir=args.tracks_dir)
    result.update(checkpoint=args.checkpoint, epoch=ckpt.get("epoch"), base_checkpoint=cfg["base_checkpoint"],
                  gate=gate_check(result, cfg), context=head.context, decision_lag=head.decision_lag,
                  defer_max=head.defer_max, defer_alpha=cfg.get("defer_alpha"), existence_calibration=calib,
                  defer_revision=head.defer_revision if head.defer_max else None, evidence=head_evidence(head),
                  future_stats=getattr(head, "future_stats", None), commit_lag=getattr(head, "commit_lag", None))
    name = Path(args.checkpoint).stem
    path = Path(args.checkpoint).parent / ("eval_%s_%s%s.json" % (args.split, name, "_" + args.tag if args.tag else ""))
    T.write_json(path, result)
    for kind in ("base", "track", "track_now"):
        if kind in result:
            r = result[kind]
            print("%s %-9s IoU %.4f ACC %.4f Pd %.4f Fa %.3e | 拖尾误报 %d 断续漏检 %d 目标附近误报 %d" % (
                args.split, kind, r["iou"], r["acc"], r["pd"], r["fa"], r["fp_cat"]["tail"], r["fn_cat"]["gap"],
                r["fp_cat"]["near"]), flush=True)
    print("航迹统计：", json.dumps(result["head_stats"], ensure_ascii=False), flush=True)
    print("关口：", json.dumps(result["gate"], ensure_ascii=False), flush=True)
    print("结果写入", path, flush=True)


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("--config", required=True)
    parser.add_argument("--mode", choices=("train", "eval"), required=True)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--split", choices=("val", "test"), default="val")
    parser.add_argument("--checkpoint", default=None, help="eval：航迹头 checkpoint")
    parser.add_argument("--dump-dir", default=None, help="eval：保存逐事件预测（含 base_probabilities）")
    parser.add_argument("--tracks-dir", default=None, help="eval：保存逐窗航迹（active / pos / vel / ex）")
    parser.add_argument("--save-root", default=None)
    parser.add_argument("--seed", type=int, default=None, help="覆盖配置中的 seed（整体模型多种子）")
    parser.add_argument("--base-checkpoint", default=None, help="覆盖配置中的骨干 checkpoint（接新训练的估计器）")
    parser.add_argument("--epochs", type=int, default=None)
    parser.add_argument("--max-chunks", type=int, default=None, help="train：每轮最多几个片段（冒烟用）")
    parser.add_argument("--max-sequences", type=int, default=None, help="每个划分只取前几条录像（冒烟用）")
    parser.add_argument("--future-stats", choices=("smoothed", "past"), default=None,
                        help="eval（RCL 消融）：past = 同一个头只用事件到达时已知的统计量（无未来）")
    parser.add_argument("--commit-lag", type=int, default=None, help="eval（RCL 消融）：固定在第 k 窗提交（k <= defer_max）")
    parser.add_argument("--tag", default=None, help="eval：评估 JSON 文件名后缀（同一权重的多种评估不互相覆盖）")
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)
    cfg = load_flat_config(args.config)
    if args.save_root:
        cfg["save_root"] = args.save_root
    if args.epochs is not None:
        cfg["epochs"] = int(args.epochs)
    if args.seed is not None:
        cfg["seed"] = int(args.seed)
    if args.base_checkpoint:
        cfg["base_checkpoint"] = args.base_checkpoint
    if args.future_stats or args.commit_lag:
        if args.mode != "eval":
            raise ValueError("--future-stats / --commit-lag 只用于 eval（消融评估）")
        if args.future_stats:
            cfg["future_stats"] = args.future_stats
        if args.commit_lag:
            cfg["commit_lag"] = int(args.commit_lag)
    if args.mode == "train":
        mode_train(args, cfg)
    else:
        if not args.checkpoint:
            raise ValueError("eval 需要 --checkpoint")
        mode_eval(args, cfg)


if __name__ == "__main__":
    main()
