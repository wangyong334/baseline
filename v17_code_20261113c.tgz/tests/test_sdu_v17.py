"""V17 decision-unit tests (11-13; CPU, synthetic data, torch 1.9 compatible).

    1. Foveated layout: 1 + 8 L boxes that tile the square of side 3^(L+1) px exactly once; box 4 holds the event
    2. Evidence maps: every box feature equals a brute-force count over the events (edge clipping, the in-frame area,
       the event itself removed from its centre box in its own window); polarity is relative, so flipping every
       polarity changes nothing; windows past the recording end are masked
    3. Decision units: start exactly at the prior (every pool and observation unit); causal (step k ignores later
       windows) in both audit modes; windows add up: with fixed gates and context the change from step k - 1 to k depends on
       window k only; steps past the last valid one keep the membrane; opponent channels keep their signs whatever the
       weights; the ablations run; step costs grow with the audited windows
    3b. Streaming: the batched window-by-window layer commits every event at the same column with the same value as
       the offline trajectories (boxes and events)
    4. Stopping rule: isotonic bound at the margin where changes stop, forced commit at the last column, entry column
       commits safe priors, unit load per window
"""
import os
import sys
import unittest

import numpy as np
import torch

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "tools", "v17"))
from model import sdu as S  # noqa: E402
import stopping as P  # noqa: E402


def recording(n=400, W=40, H=30, n_win=5, seed=0):
    rng = np.random.RandomState(seed)
    return {"x": rng.randint(0, W, n), "y": rng.randint(0, H, n), "win": rng.randint(0, n_win, n),
            "pol": rng.randint(0, 2, n), "z0": rng.randn(n).astype(np.float32) * 4.0, "W": W, "H": H, "n_win": n_win}


def brute(rec, e, rect, n_steps):
    """Features of event e by direct counting."""
    q = np.round(1.0 / (1.0 + np.exp(-rec["z0"].astype(np.float64))) * S.Q_SCALE)
    out = np.zeros((n_steps, len(rect), S.N_FEAT))
    ok = np.zeros(n_steps, bool)
    for s in range(n_steps):
        w = rec["win"][e] + s
        if w >= rec["n_win"]:
            continue
        ok[s] = True
        for k, (x0, x1, y0, y1) in enumerate(rect):
            gx0, gx1, gy0, gy1 = rec["x"][e] + x0, rec["x"][e] + x1, rec["y"][e] + y0, rec["y"][e] + y1
            inside = ((rec["win"] == w) & (rec["x"] >= gx0) & (rec["x"] <= gx1) & (rec["y"] >= gy0) &
                      (rec["y"] <= gy1))
            if s == 0:
                inside[e] = False
            same = inside & (rec["pol"] == rec["pol"][e])
            opp = inside & (rec["pol"] != rec["pol"][e])
            cx = max(0, min(gx1, rec["W"] - 1) - max(gx0, 0) + 1)
            cy = max(0, min(gy1, rec["H"] - 1) - max(gy0, 0) + 1)
            area = cx * cy / float((x1 - x0 + 1) * (y1 - y0 + 1))
            out[s, k] = [np.log1p(same.sum()), np.log1p(opp.sum()), np.log1p(q[same].sum() / S.Q_SCALE),
                         np.log1p(q[opp].sum() / S.Q_SCALE), area]
    return out, ok


def maps_of(rec):
    return S.EvidenceMaps(rec["x"], rec["y"], rec["win"], rec["pol"], rec["z0"], rec["n_win"], rec["H"], rec["W"],
                          "cpu")


class LayoutTests(unittest.TestCase):
    def test_tiling(self):
        for L in (1, 2, 3, 4):
            rect, r, lev = S.box_layout(L)
            self.assertEqual(len(rect), 1 + 8 * L)
            h = (3 ** (L + 1) - 1) // 2
            cover = np.zeros((2 * h + 1, 2 * h + 1), int)
            for x0, x1, y0, y1 in rect:
                cover[y0 + h:y1 + h + 1, x0 + h:x1 + h + 1] += 1
            self.assertTrue((cover == 1).all(), "level %d" % L)
            x0, x1, y0, y1 = rect[S.CENTRE]
            self.assertTrue(x0 <= 0 <= x1 and y0 <= 0 <= y1)
            self.assertEqual(r[S.CENTRE], 0.0)
            self.assertEqual(lev.max(), L - 1)


class MapTests(unittest.TestCase):
    def setUp(self):
        self.rec = recording()
        self.rect, _, _ = S.box_layout(2)
        self.maps = maps_of(self.rec)

    def features(self, rec, maps, idx, n_steps=3):
        return maps.features(rec["x"][idx], rec["y"][idx], rec["win"][idx], rec["pol"][idx], rec["z0"][idx],
                             self.rect, n_steps)

    def test_brute_force(self):
        idx = np.arange(0, 400, 7)
        feat, ok = self.features(self.rec, self.maps, idx)
        for j, e in enumerate(idx):
            ref, ref_ok = brute(self.rec, e, self.rect, 3)
            np.testing.assert_array_equal(ok[j].numpy(), ref_ok)
            np.testing.assert_allclose(feat[j].numpy(), ref * ref_ok[:, None, None], rtol=1e-5, atol=1e-5)

    def test_polarity_relative(self):
        flipped = dict(self.rec, pol=1 - self.rec["pol"])
        idx = np.arange(0, 400, 5)
        a, _ = self.features(self.rec, self.maps, idx)
        b, _ = self.features(flipped, maps_of(flipped), idx)
        np.testing.assert_array_equal(a.numpy(), b.numpy())

    def test_mask_past_end(self):
        last = np.nonzero(self.rec["win"] == self.rec["n_win"] - 1)[0][:5]
        feat, ok = self.features(self.rec, self.maps, last)
        self.assertTrue(ok[:, 0].all())
        self.assertFalse(ok[:, 1:].any())
        self.assertEqual(float(feat[:, 1:].abs().sum()), 0.0)


def unit(value="ei", gate="attribution", pool="window", evidence="boxes", context=True, audit="reaudit", n_steps=4,
         levels=2, nonzero=True):
    torch.manual_seed(1)
    _, r, _ = S.box_layout(levels)
    net = S.SpikingDecisionUnits(n_steps, r, dim=16, heads=4, value=value, gate=gate, pool=pool, evidence=evidence,
                                 context=context, audit=audit)
    if nonzero:
        with torch.no_grad():
            net.v_out.weight.normal_(0, 0.5)
            net.v_out.bias.normal_(0, 0.5)
            net.wm.weight.normal_(0, 0.3)
            if evidence == "events":
                net.sink_val.weight.normal_(0, 0.5)
                net.sink_logit.normal_(0, 1.0)
    return net.eval()


def unit_inputs(B=5, n_steps=4, K=17, seed=0):
    g = torch.Generator().manual_seed(seed)
    feat = torch.rand(B, n_steps, K, S.N_FEAT, generator=g) * 3.0
    valid = torch.ones(B, n_steps, dtype=torch.bool)
    z0 = torch.randn(B, generator=g) * 3.0
    pol = (torch.rand(B, generator=g) > 0.5).long()
    return feat, valid, z0, pol


class UnitTests(unittest.TestCase):
    def test_starts_at_prior(self):
        feat, valid, z0, pol = unit_inputs()
        for value in ("ei", "signed"):
            for audit in ("reaudit", "ledger"):
                for pool, evidence in (("window", "boxes"), ("mean", "boxes"), ("window", "events")):
                    net = unit(value=value, audit=audit, pool=pool, evidence=evidence, nonzero=False)
                    with torch.no_grad():
                        U = net(feat, valid, z0, pol)
                    self.assertLess(float((U - z0[:, None]).abs().max()), 1e-5,
                                    "%s %s %s %s" % (value, audit, pool, evidence))

    def test_windows_add_up(self):
        feat, valid, z0, pol = unit_inputs()
        for evidence in ("boxes", "events"):                    # fixed gates and context: each window's evidence is
            net = unit(context=False, gate="distance", evidence=evidence)    # the same at every step
            with torch.no_grad():
                U = net(feat, valid, z0, pol)
                f2 = feat.clone()
                f2[:, :2] = torch.rand_like(f2[:, :2]) * 5.0             # change windows 0 and 1 only
                U2 = net(f2, valid, z0, pol)
            np.testing.assert_allclose((U2[:, 3] - U2[:, 2]).numpy(), (U[:, 3] - U[:, 2]).numpy(), rtol=1e-4,
                                       atol=1e-4)
            self.assertGreater(float((U2[:, 1] - U[:, 1]).abs().max()), 1e-3)

    def test_causal(self):
        feat, valid, z0, pol = unit_inputs()
        for audit in ("reaudit", "ledger"):
            net = unit(audit=audit)
            with torch.no_grad():
                U = net(feat, valid, z0, pol)
                for k in range(3):
                    f2 = feat.clone()
                    f2[:, k + 1:] = torch.rand_like(f2[:, k + 1:]) * 5.0
                    U2 = net(f2, valid, z0, pol)
                    np.testing.assert_allclose(U2[:, :k + 1].numpy(), U[:, :k + 1].numpy(), rtol=1e-6, atol=1e-6)
                    self.assertGreater(float((U2[:, k + 1:] - U[:, k + 1:]).abs().max()), 1e-4)

    def test_frozen_after_last_valid(self):
        feat, valid, z0, pol = unit_inputs()
        valid[:, 2:] = False
        net = unit()
        with torch.no_grad():
            U = net(feat, valid, z0, pol)
        np.testing.assert_array_equal(U[:, 2].numpy(), U[:, 1].numpy())
        np.testing.assert_array_equal(U[:, 3].numpy(), U[:, 1].numpy())

    def test_opponent_signs(self):
        feat, valid, z0, pol = unit_inputs()
        net = unit(value="ei")
        with torch.no_grad():
            net(feat, valid, z0, pol, keep=True)
        lam = net.extras["lam"]
        self.assertTrue(bool((lam[..., :2] >= 0).all()) and bool((lam[..., 2:] <= 0).all()))
        self.assertEqual(tuple(net.extras["gates"].shape), (5, 4, 4, 4 * 17))

    def test_ablations_run(self):
        feat, valid, z0, pol = unit_inputs()
        for kw in ({"gate": "distance"}, {"pool": "sum"}, {"pool": "mean"}, {"context": False},
                   {"value": "signed", "pool": "sum"}, {"evidence": "events"}, {"audit": "ledger", "evidence": "events"}):
            net = unit(**kw)
            with torch.no_grad():
                U = net(feat, valid, z0, pol)
            self.assertTrue(bool(torch.isfinite(U).all()), str(kw))

    def test_step_cost_grows(self):
        net = unit()
        c = [net.step_macs(k) for k in range(4)]
        self.assertTrue(all(b > a for a, b in zip(c[1:], c[2:])))
        self.assertGreater(c[0], c[1] - (net.step_macs(2) - net.step_macs(1)))


class StreamingTests(unittest.TestCase):
    def test_stream_equals_offline(self):
        for evidence in ("boxes", "events"):
            self.check_stream(evidence)

    def check_stream(self, evidence):
        rec = recording(n=600, W=40, H=30, n_win=7, seed=3)
        rect, r, _ = S.box_layout(2)
        n_steps = 4
        net = unit(n_steps=n_steps, evidence=evidence)
        maps = maps_of(rec)
        idx = np.arange(len(rec["x"]))
        F_ = np.minimum(n_steps - 1, rec["n_win"] - 1 - rec["win"])
        with torch.no_grad():
            feat, ok = maps.features(rec["x"], rec["y"], rec["win"], rec["pol"], rec["z0"], rect, n_steps)
            U = net(feat, ok, torch.as_tensor(rec["z0"]), torch.as_tensor(rec["pol"])).numpy()
        tau = -1.2
        Z = np.concatenate([rec["z0"][:, None], U], 1).astype(np.float64)
        bounds = [2.5, 2.0, 1.5, 1.0, 0.0]
        L = P.commit(Z, 1 + F_, tau, bounds)
        layer = S.StreamingDecisionLayer(net, rect, bounds, tau, rec["H"], rec["W"], "cpu")
        col = np.full(len(idx), -1)
        val = np.zeros(len(idx))
        for t in range(rec["n_win"]):
            ids = idx[rec["win"] == t]
            e, c, v = layer.window(t, rec["x"][ids], rec["y"][ids], rec["pol"][ids], rec["z0"][ids], ids, F_[ids])
            col[e], val[e] = c, v
        self.assertEqual(layer.open_units(), 0)
        np.testing.assert_array_equal(col, L)
        np.testing.assert_allclose(val, Z[np.arange(len(idx)), L], rtol=1e-5, atol=1e-5)
        self.assertTrue(0 < (L == 0).sum() < len(L) and (L > 1).any())


class StoppingTests(unittest.TestCase):
    def test_bound_where_changes_stop(self):
        rng = np.random.RandomState(0)
        m = rng.rand(20000) * 10.0
        change = (m < 3.0) & (rng.rand(20000) < 0.4)
        b = P.bound_from_changes(m, change, 0.01, 0.01)
        self.assertGreater(b, 2.95)                          # just after the last change below 3
        self.assertLess(b, 3.5)
        self.assertEqual(P.bound_from_changes(m, np.ones_like(change), 0.01, 0.01), float("inf"))

    def test_calibrate_and_commit(self):
        rng = np.random.RandomState(1)
        n, C, tau = 6000, 5, 0.0
        z0 = rng.randn(n) * 4.0
        drift = np.sign(rng.randn(n)) * 1.5
        Z = np.stack([z0 + drift * c * (np.abs(z0) < 2) for c in range(C)], 1)
        last = np.full(n, C - 1)
        last[:300] = 2
        b = P.calibrate(Z, last, tau, 0.01, 0.1)
        self.assertEqual(len(b), C)
        self.assertEqual(b[-1], 0.0)
        L = P.commit(Z, last, tau, b)
        self.assertTrue((L <= last).all())
        self.assertTrue((L[np.abs(z0) > b[0]] == 0).all())
        final = Z[np.arange(n), last] >= tau
        changed = (Z[np.arange(n), L] >= tau) != final
        self.assertLess(changed.mean(), 0.01)

    def test_unit_load(self):
        win = np.array([0, 0, 1, 3])
        L = np.array([0, 2, 3, 1])                  # columns: 0 = entry commit, k >= 1 ran steps 0 .. k - 1
        rec = np.zeros(4, np.int64)
        units, macs = P.unit_load(win, L, {0: 5}, rec, 3, lambda k: 10.0 * (k + 1))
        np.testing.assert_array_equal(units, [1, 2, 1, 2, 0])
        np.testing.assert_allclose(macs, [10, 30, 20, 40, 0])


if __name__ == "__main__":
    unittest.main()
